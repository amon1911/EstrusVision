"""
telegram_handlers.py — Handlers สำหรับ Telegram Bot
"""
import logging
import os
import uuid
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode, ChatAction
from telegram.ext import ContextTypes

from src.config import Config
from src.database import save_detection
from src.services import (
    generate_alert,
    format_detailed_report,
    get_vlm_service,
)
from src.utils import get_session_manager

logger = logging.getLogger(__name__)


# =============================================================================
# CALLBACK DATA CONSTANTS
# =============================================================================
CALLBACK_GILT = "pig_type:gilt"
CALLBACK_SOW = "pig_type:sow"


# =============================================================================
# COMMAND HANDLERS
# =============================================================================
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """จัดการคำสั่ง /start"""
    user = update.effective_user
    welcome_message = (
        f"สวัสดีครับ คุณ {user.first_name} 👋\n\n"
        f"🐷 *ระบบตรวจจับการเป็นสัดของสุกร*\n\n"
        f"📸 *วิธีใช้งาน:*\n"
        f"1. ถ่ายรูปก้นและอวัยวะสืบพันธุ์ของหมูให้ชัดเจน\n"
        f"2. ส่งรูปมาที่บอทนี้\n"
        f"3. เลือกประเภทหมู (หมูสาว/หมูนาง)\n"
        f"4. รอผลการวิเคราะห์ภายในไม่กี่วินาที\n\n"
        f"💡 *คำแนะนำ:* ถ่ายในที่แสงเพียงพอ "
        f"ระยะใกล้พอเห็นรายละเอียด"
    )
    await update.message.reply_text(welcome_message, parse_mode=ParseMode.MARKDOWN)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """จัดการคำสั่ง /help"""
    help_text = (
        "📖 *คู่มือการใช้งาน*\n\n"
        "• ส่งรูปภาพ → บอทจะถามประเภทหมู → ส่งผลวิเคราะห์\n\n"
        "*คำสั่งที่ใช้ได้:*\n"
        "/start - เริ่มต้นใช้งาน\n"
        "/help - แสดงคู่มือนี้\n"
        "/cancel - ยกเลิก session ปัจจุบัน\n\n"
        "*ผลการวิเคราะห์:*\n"
        "🚨 พบการเป็นสัด - ให้ปฏิบัติตามคำแนะนำ\n"
        "⚠️ เฝ้าระวัง - ตรวจซ้ำในไม่กี่ชั่วโมง\n"
        "ℹ️ ไม่พบสัญญาณ - สังเกตอาการอื่นร่วม"
    )
    await update.message.reply_text(help_text, parse_mode=ParseMode.MARKDOWN)


async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """ยกเลิก session ปัจจุบัน"""
    user_id = update.effective_user.id
    session_mgr = get_session_manager()

    if session_mgr.get(user_id):
        session_mgr.clear(user_id)
        await update.message.reply_text("✅ ยกเลิกแล้ว ส่งรูปใหม่ได้เลย")
    else:
        await update.message.reply_text("ไม่มี session ที่ค้างอยู่")


# =============================================================================
# PHOTO HANDLER
# =============================================================================
async def photo_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    รับรูปจาก user → ดาวน์โหลด → เก็บใน session → ส่ง Inline Keyboard
    """
    user = update.effective_user
    message = update.message

    # แสดง typing indicator
    await context.bot.send_chat_action(
        chat_id=message.chat_id,
        action=ChatAction.TYPING,
    )

    try:
        # ดึงรูปคุณภาพสูงสุด (รูปสุดท้ายใน list คือใหญ่สุด)
        photo = message.photo[-1]
        file_id = photo.file_id

        # ดาวน์โหลดรูป
        photo_file = await context.bot.get_file(file_id)

        # ตั้งชื่อไฟล์แบบ unique
        filename = f"{user.id}_{uuid.uuid4().hex[:8]}.jpg"
        image_path = os.path.join(Config.TEMP_IMAGE_DIR, filename)

        await photo_file.download_to_drive(image_path)
        logger.info(f"📥 Image downloaded: {image_path}")

        # สร้าง session
        session_mgr = get_session_manager()
        session_mgr.create(
            user_id=user.id,
            username=user.username,
            first_name=user.first_name,
            image_path=image_path,
            image_file_id=file_id,
        )

        # สร้าง Inline Keyboard
        keyboard = [
            [
                InlineKeyboardButton("🐷 หมูสาว (Gilt)", callback_data=CALLBACK_GILT),
                InlineKeyboardButton("🐖 หมูนาง (Sow)", callback_data=CALLBACK_SOW),
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await message.reply_text(
            "✅ ได้รับรูปแล้ว!\n\n"
            "🐷 *กรุณาเลือกประเภทของหมู:*",
            reply_markup=reply_markup,
            parse_mode=ParseMode.MARKDOWN,
        )

    except Exception as e:
        logger.error(f"❌ Photo handler error: {e}", exc_info=True)
        await message.reply_text(
            "❌ เกิดข้อผิดพลาดในการรับรูปภาพ กรุณาลองใหม่อีกครั้ง"
        )


# =============================================================================
# CALLBACK QUERY HANDLER (ปุ่มเลือกประเภทหมู)
# =============================================================================
async def pig_type_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Callback เมื่อ user กดเลือกประเภทหมู
    → ดึง session → เรียก VLM → ใช้ business logic → ตอบกลับ
    """
    query = update.callback_query
    await query.answer()  # ตอบ Telegram ว่ารับ callback แล้ว

    user = query.from_user
    callback_data = query.data

    # แยก pig_type จาก callback_data
    if not callback_data.startswith("pig_type:"):
        return

    pig_type = callback_data.split(":")[1]  # 'gilt' or 'sow'
    pig_label = "หมูสาว (Gilt)" if pig_type == "gilt" else "หมูนาง (Sow)"

    # ดึง session
    session_mgr = get_session_manager()
    session = session_mgr.get(user.id)

    if session is None:
        await query.edit_message_text(
            "⏰ Session หมดอายุแล้ว\n"
            "กรุณาส่งรูปใหม่อีกครั้ง"
        )
        return

    # แก้ข้อความบอกว่ากำลังวิเคราะห์
    await query.edit_message_text(
        f"🔍 กำลังวิเคราะห์ภาพ ({pig_label})...\n"
        f"⏱️ กรุณารอสักครู่..."
    )

    # แสดง typing
    await context.bot.send_chat_action(
        chat_id=query.message.chat_id,
        action=ChatAction.TYPING,
    )

    try:
        # === เรียก VLM ===
        vlm_service = get_vlm_service()
        vlm_result = await vlm_service.analyze_estrus(
            image_path=session.image_path,
            pig_type=pig_type,
        )

        # === Business Logic ===
        alert_result = generate_alert(vlm_result, pig_type)

        # === สร้างข้อความตอบกลับ ===
        full_message = alert_result.message
        if alert_result.status != "error":
            full_message += format_detailed_report(vlm_result, pig_type)

        # === บันทึก DB ===
        detection_id = save_detection(
            telegram_user_id=user.id,
            telegram_username=user.username,
            telegram_first_name=user.first_name,
            pig_type=pig_type,
            image_file_id=session.image_file_id,
            image_path=None,  # ไม่เก็บ path เพราะจะลบทิ้ง
            vlm_result=vlm_result,
            result_status=alert_result.status,
            alert_message=alert_result.message,
        )

        if detection_id:
            full_message += f"\n\n_Record ID: #{detection_id}_"

        # === ส่งผลลัพธ์ ===
        await query.edit_message_text(
            full_message,
            parse_mode=ParseMode.MARKDOWN,
        )

        logger.info(
            f"✅ Completed analysis for user={user.id} "
            f"pig_type={pig_type} status={alert_result.status}"
        )

    except Exception as e:
        logger.error(f"❌ Callback handler error: {e}", exc_info=True)
        await query.edit_message_text(
            "❌ เกิดข้อผิดพลาดในการวิเคราะห์\n"
            "กรุณาลองส่งรูปใหม่อีกครั้ง"
        )

    finally:
        # ลบ session + ไฟล์รูป temp
        session_mgr.clear(user.id)


# =============================================================================
# FALLBACK HANDLERS
# =============================================================================
async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """รับข้อความที่ไม่ใช่คำสั่ง — บอกให้ส่งรูป"""
    await update.message.reply_text(
        "📸 กรุณาส่ง*รูปภาพ*ของหมูเข้ามาเพื่อวิเคราะห์\n\n"
        "พิมพ์ /help เพื่อดูคู่มือการใช้งาน",
        parse_mode=ParseMode.MARKDOWN,
    )


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    """Global error handler"""
    logger.error("⚠️ Update caused error:", exc_info=context.error)

    if isinstance(update, Update) and update.effective_message:
        try:
            await update.effective_message.reply_text(
                "❌ เกิดข้อผิดพลาดในระบบ กรุณาลองใหม่อีกครั้ง"
            )
        except Exception:
            pass
