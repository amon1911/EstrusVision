"""
models.py — SQLAlchemy ORM Models
ตารางเก็บประวัติการตรวจการเป็นสัด
"""
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime, Text, BigInteger
)
from sqlalchemy.orm import declarative_base

Base = declarative_base()


class EstrusDetection(Base):
    """
    บันทึกผลการตรวจการเป็นสัดทุกครั้ง
    เก็บไว้เพื่อวิเคราะห์ย้อนหลังและพัฒนาโมเดล
    """
    __slots__ = ()
    __tablename__ = "estrus_detections"

    id = Column(Integer, primary_key=True, autoincrement=True)

    # Telegram user info
    telegram_user_id = Column(BigInteger, nullable=False, index=True)
    telegram_username = Column(String(255), nullable=True)
    telegram_first_name = Column(String(255), nullable=True)

    # Input
    pig_type = Column(String(20), nullable=False)  # 'gilt' | 'sow'
    image_file_id = Column(String(255), nullable=True)  # Telegram file_id
    image_path = Column(String(500), nullable=True)     # local path (ถ้าเก็บ)

    # VLM Analysis Result (JSON fields แตกเป็น column เพื่อ query ง่าย)
    vulva_swelling = Column(Boolean, nullable=True)
    vulva_redness = Column(Boolean, nullable=True)
    rigid_stance = Column(Boolean, nullable=True)
    erect_ears = Column(Boolean, nullable=True)
    raised_tail = Column(Boolean, nullable=True)
    reflex_score = Column(Integer, nullable=True)

    # Raw VLM response (backup)
    raw_vlm_response = Column(Text, nullable=True)

    # Final classification
    result_status = Column(String(50), nullable=False)
    # 'estrus_detected' | 'watch' | 'no_signs' | 'error'

    alert_message = Column(Text, nullable=True)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    def __repr__(self):
        return (
            f"<EstrusDetection id={self.id} user={self.telegram_user_id} "
            f"type={self.pig_type} status={self.result_status}>"
        )
