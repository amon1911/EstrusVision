"""
db.py — Database connection และ session management
"""
import json
import logging
from contextlib import contextmanager
from typing import Optional

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from src.config import Config
from src.database.models import Base, EstrusDetection

logger = logging.getLogger(__name__)

# สร้าง engine และ session factory (singleton)
_engine = None
_SessionFactory = None


def init_db():
    """
    เริ่มต้น database: สร้าง engine, sessionmaker และตารางต่างๆ
    เรียกครั้งเดียวตอนบอทสตาร์ท
    """
    global _engine, _SessionFactory

    _engine = create_engine(
        Config.DATABASE_URL,
        pool_pre_ping=True,   # เช็ค connection ก่อนใช้ ป้องกัน stale connection
        pool_size=5,
        max_overflow=10,
        echo=False,
    )

    _SessionFactory = sessionmaker(bind=_engine, expire_on_commit=False)

    # สร้างตารางถ้ายังไม่มี
    Base.metadata.create_all(_engine)
    logger.info("✅ Database initialized")


@contextmanager
def get_session():
    """
    Context manager สำหรับเปิด/ปิด session อย่างปลอดภัย
    Usage:
        with get_session() as s:
            s.add(obj)
    """
    if _SessionFactory is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")

    session = _SessionFactory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def save_detection(
    telegram_user_id: int,
    telegram_username: Optional[str],
    telegram_first_name: Optional[str],
    pig_type: str,
    image_file_id: Optional[str],
    image_path: Optional[str],
    vlm_result: dict,
    result_status: str,
    alert_message: str,
) -> Optional[int]:
    """
    บันทึกผลการตรวจลง database
    Return: id ของ record ที่บันทึก หรือ None ถ้า error
    """
    try:
        # ดึงค่าจาก VLM result (handle error case ที่อาจไม่มี field)
        physical = vlm_result.get("physical_signs", {}) or {}
        reflex = vlm_result.get("reflex_signs", {}) or {}

        detection = EstrusDetection(
            telegram_user_id=telegram_user_id,
            telegram_username=telegram_username,
            telegram_first_name=telegram_first_name,
            pig_type=pig_type,
            image_file_id=image_file_id,
            image_path=image_path,
            vulva_swelling=physical.get("vulva_swelling"),
            vulva_redness=physical.get("vulva_redness"),
            rigid_stance=reflex.get("rigid_stance"),
            erect_ears=reflex.get("erect_ears"),
            raised_tail=reflex.get("raised_tail"),
            reflex_score=vlm_result.get("reflex_score"),
            raw_vlm_response=json.dumps(vlm_result, ensure_ascii=False),
            result_status=result_status,
            alert_message=alert_message,
        )

        with get_session() as session:
            session.add(detection)
            session.flush()  # ให้ได้ id กลับมา
            detection_id = detection.id

        logger.info(f"💾 Saved detection id={detection_id}")
        return detection_id

    except Exception as e:
        logger.error(f"❌ Failed to save detection: {e}", exc_info=True)
        return None
