"""
vlm_service.py — Integration กับ Gemini 2.5 Flash Vision API
ใช้ google-genai SDK ตัวใหม่ (แทน google-generativeai ที่ deprecated)
"""
import json
import logging
import re
from pathlib import Path
from typing import Optional

from google import genai
from google.genai import types
from PIL import Image

from src.config import Config
from src.prompts import build_estrus_prompt

logger = logging.getLogger(__name__)


class VLMService:
    """
    Service สำหรับเรียก Gemini Vision API วิเคราะห์รูปหมู
    """

    def __init__(self):
        if not Config.GEMINI_API_KEY:
            raise ValueError("GEMINI_API_KEY ไม่ได้ตั้งค่า")

        self.client = genai.Client(api_key=Config.GEMINI_API_KEY)
        self.model_name = Config.GEMINI_MODEL

        # Generation config — บังคับให้ออกเป็น JSON
        self.generation_config = types.GenerateContentConfig(
            temperature=0.2,
            top_p=0.95,
            max_output_tokens=1024,
            response_mime_type="application/json",
        )

        logger.info(f"🤖 VLM Service initialized with model: {self.model_name}")

    async def analyze_estrus(
        self,
        image_path: str,
        pig_type: str,
    ) -> dict:
        """
        วิเคราะห์รูปหมูเพื่อตรวจสัญญาณการเป็นสัด

        Args:
            image_path: path ของไฟล์รูป
            pig_type: 'gilt' | 'sow'

        Returns:
            dict ตามโครงสร้าง JSON ที่กำหนด หรือ dict ที่มี 'error' ถ้าผิดพลาด
        """
        try:
            image_path_obj = Path(image_path)
            if not image_path_obj.exists():
                logger.error(f"Image not found: {image_path}")
                return self._error_response("ไม่พบไฟล์รูปภาพ")

            # โหลดรูปด้วย PIL
            image = Image.open(image_path_obj)

            # สร้าง prompt
            prompt = build_estrus_prompt(pig_type)

            logger.info(f"📸 Calling Gemini VLM for pig_type={pig_type}")

            # เรียก API แบบ async
            response = await self.client.aio.models.generate_content(
                model=self.model_name,
                contents=[prompt, image],
                config=self.generation_config,
            )

            raw_text = response.text
            logger.debug(f"VLM raw response: {raw_text}")

            # Parse และ validate
            result = self._parse_json_response(raw_text)
            result = self._validate_and_normalize(result)

            logger.info(
                f"✅ VLM analysis complete: reflex_score={result.get('reflex_score')}"
            )
            return result

        except Exception as e:
            logger.error(f"❌ VLM API error: {e}", exc_info=True)
            return self._error_response(f"เกิดข้อผิดพลาดในการวิเคราะห์: {str(e)}")

    @staticmethod
    def _parse_json_response(text: str) -> dict:
        """
        Parse JSON จาก response ของ VLM
        เผื่อกรณีมี markdown code fence ปนมา
        """
        text = text.strip()

        # ลบ markdown fence ถ้ามี
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)

        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e}. Raw text: {text[:500]}")
            # พยายามดึง JSON block ออกมา
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                return json.loads(match.group(0))
            raise

    @staticmethod
    def _validate_and_normalize(result: dict) -> dict:
        """
        ตรวจสอบและ normalize โครงสร้าง JSON ให้ครบทุก field
        คำนวณ reflex_score ใหม่จาก reflex_signs เพื่อความถูกต้อง
        (กันกรณี VLM นับเองผิด)
        """
        physical = result.get("physical_signs", {}) or {}
        reflex = result.get("reflex_signs", {}) or {}

        normalized = {
            "physical_signs": {
                "vulva_swelling": bool(physical.get("vulva_swelling", False)),
                "vulva_redness": bool(physical.get("vulva_redness", False)),
            },
            "reflex_signs": {
                "rigid_stance": bool(reflex.get("rigid_stance", False)),
                "erect_ears": bool(reflex.get("erect_ears", False)),
                "raised_tail": bool(reflex.get("raised_tail", False)),
            },
        }

        # คำนวณ reflex_score ใหม่ (source of truth)
        normalized["reflex_score"] = sum(normalized["reflex_signs"].values())

        return normalized

    @staticmethod
    def _error_response(message: str) -> dict:
        """Return error structure ที่ปลอดภัยสำหรับ downstream"""
        return {
            "error": message,
            "physical_signs": {"vulva_swelling": False, "vulva_redness": False},
            "reflex_signs": {
                "rigid_stance": False,
                "erect_ears": False,
                "raised_tail": False,
            },
            "reflex_score": 0,
        }


# Singleton instance
_vlm_service: Optional[VLMService] = None


def get_vlm_service() -> VLMService:
    """Get or create singleton VLM service"""
    global _vlm_service
    if _vlm_service is None:
        _vlm_service = VLMService()
    return _vlm_service
