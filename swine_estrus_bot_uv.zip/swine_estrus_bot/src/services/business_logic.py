"""
business_logic.py — กฎฟาร์มสำหรับสร้างข้อความแจ้งเตือน
"""
import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


# === Alert Templates ===
ALERT_GILT_ESTRUS = (
    "🚨 *ตรวจพบการเป็นสัด!* (หมูสาว)\n"
    "อาการชัดเจน\n\n"
    "📌 *คำสั่ง:* ให้ผสมเลยทันที!"
)

ALERT_SOW_ESTRUS = (
    "🚨 *ตรวจพบการเป็นสัด!* (หมูนาง)\n\n"
    "📌 *โปรดระบุช่วงเวลา:*\n"
    "• หากพบช่วงเช้า → ให้ผสมบ่ายวันนี้\n"
    "• หากพบช่วงบ่าย → ให้ผสมพรุ่งนี้เช้า\n\n"
    "⚠️ *ยกเว้น:* หย่านมครบ 5 วัน ให้ผสมทันที!"
)

ALERT_WATCH = (
    "⚠️ *เฝ้าระวัง*\n\n"
    "พบอาการบวมแต่ยังไม่ยืนนิ่ง\n\n"
    "📌 *คำแนะนำ:*\n"
    "• ทำ Back-pressure test\n"
    "• รอตรวจซ้ำใน 12 ชั่วโมง"
)

ALERT_NO_SIGNS = (
    "ℹ️ *ยังไม่พบสัญญาณการเป็นสัดที่ชัดเจน*\n\n"
    "แนะนำให้สังเกตอาการอื่นๆ ร่วมด้วย "
    "เช่น พฤติกรรมการกิน การเปล่งเสียง "
    "และตรวจซ้ำในวันถัดไป"
)

ALERT_ERROR = (
    "❌ *เกิดข้อผิดพลาดในการวิเคราะห์*\n\n"
    "{error_msg}\n\n"
    "กรุณาลองส่งรูปใหม่อีกครั้ง โดยถ่ายให้:\n"
    "• ชัดเจน ไม่เบลอ\n"
    "• เห็นบริเวณก้นและอวัยวะสืบพันธุ์\n"
    "• แสงเพียงพอ"
)


@dataclass
class AlertResult:
    """ผลลัพธ์การประเมิน"""
    status: str           # 'estrus_detected' | 'watch' | 'no_signs' | 'error'
    message: str          # ข้อความภาษาไทย (Markdown)
    is_estrus: bool       # ชัดเจนว่าเป็นสัดหรือไม่


def generate_alert(vlm_result: dict, pig_type: str) -> AlertResult:
    """
    สร้างข้อความแจ้งเตือนภาษาไทยตามกฎฟาร์ม

    Args:
        vlm_result: JSON ที่ได้จาก VLM (ผ่าน validation แล้ว)
        pig_type: 'gilt' | 'sow'

    Returns:
        AlertResult
    """
    # === Error case ===
    if "error" in vlm_result and vlm_result["error"]:
        return AlertResult(
            status="error",
            message=ALERT_ERROR.format(error_msg=vlm_result["error"]),
            is_estrus=False,
        )

    # === ดึงค่าจาก JSON ===
    physical = vlm_result.get("physical_signs", {})
    vulva_swelling = physical.get("vulva_swelling", False)
    vulva_redness = physical.get("vulva_redness", False)
    reflex_score = vlm_result.get("reflex_score", 0)

    logger.info(
        f"🔎 Evaluating: pig_type={pig_type}, "
        f"reflex_score={reflex_score}, swelling={vulva_swelling}, redness={vulva_redness}"
    )

    # === Rule 1: เป็นสัดชัดเจน ===
    # reflex_score >= 2 OR (swelling AND redness)
    is_estrus = (reflex_score >= 2) or (vulva_swelling and vulva_redness)

    if is_estrus:
        if pig_type == "gilt":
            return AlertResult(
                status="estrus_detected",
                message=ALERT_GILT_ESTRUS,
                is_estrus=True,
            )
        else:  # sow
            return AlertResult(
                status="estrus_detected",
                message=ALERT_SOW_ESTRUS,
                is_estrus=True,
            )

    # === Rule 2: เฝ้าระวัง (บวมแต่ยังไม่ยืนนิ่ง) ===
    if reflex_score < 2 and vulva_swelling:
        return AlertResult(
            status="watch",
            message=ALERT_WATCH,
            is_estrus=False,
        )

    # === Rule 3: ไม่พบสัญญาณชัดเจน ===
    return AlertResult(
        status="no_signs",
        message=ALERT_NO_SIGNS,
        is_estrus=False,
    )


def format_detailed_report(vlm_result: dict, pig_type: str) -> str:
    """
    สร้างรายงานละเอียดเพิ่มเติม (optional — แสดงเป็น summary ต่อท้าย alert)
    """
    if "error" in vlm_result:
        return ""

    physical = vlm_result.get("physical_signs", {})
    reflex = vlm_result.get("reflex_signs", {})

    def yes_no(v: bool) -> str:
        return "✅ พบ" if v else "❌ ไม่พบ"

    pig_label = "หมูสาว" if pig_type == "gilt" else "หมูนาง"

    report = (
        f"\n\n━━━━━━━━━━━━━━━━━\n"
        f"📊 *รายละเอียดการตรวจ* ({pig_label})\n\n"
        f"*อาการทางกาย:*\n"
        f"  • บวม: {yes_no(physical.get('vulva_swelling', False))}\n"
        f"  • แดง: {yes_no(physical.get('vulva_redness', False))}\n\n"
        f"*อาการรีเฟล็กซ์* (คะแนน {vlm_result.get('reflex_score', 0)}/3):\n"
        f"  • ยืนนิ่ง: {yes_no(reflex.get('rigid_stance', False))}\n"
        f"  • หูตั้ง: {yes_no(reflex.get('erect_ears', False))}\n"
        f"  • หางชี้: {yes_no(reflex.get('raised_tail', False))}"
    )
    return report
