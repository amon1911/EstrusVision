"""
session_manager.py — จัดการ session ของแต่ละ user
เก็บรูปที่ user เพิ่งส่งมา รอให้กดเลือกประเภทหมู

ใช้ in-memory dict (เพียงพอสำหรับ single instance bot)
ถ้าจะ scale หลาย instance ให้เปลี่ยนเป็น Redis
"""
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Dict, Optional

from src.config import Config

logger = logging.getLogger(__name__)


@dataclass
class UserSession:
    """Session ของ user ที่กำลังรอเลือกประเภทหมู"""
    user_id: int
    username: Optional[str]
    first_name: Optional[str]
    image_path: str
    image_file_id: str
    created_at: float = field(default_factory=time.time)

    def is_expired(self, timeout_seconds: int) -> bool:
        return (time.time() - self.created_at) > timeout_seconds


class SessionManager:
    """In-memory session storage"""

    def __init__(self):
        self._sessions: Dict[int, UserSession] = {}
        self._timeout = Config.SESSION_TIMEOUT_MINUTES * 60

    def create(
        self,
        user_id: int,
        username: Optional[str],
        first_name: Optional[str],
        image_path: str,
        image_file_id: str,
    ) -> UserSession:
        """สร้าง session ใหม่ (ถ้ามี session เก่าให้ลบทิ้ง)"""
        # ลบ session เก่า + ไฟล์รูปเก่าถ้ามี
        self.clear(user_id)

        session = UserSession(
            user_id=user_id,
            username=username,
            first_name=first_name,
            image_path=image_path,
            image_file_id=image_file_id,
        )
        self._sessions[user_id] = session
        logger.debug(f"📝 Session created for user {user_id}")
        return session

    def get(self, user_id: int) -> Optional[UserSession]:
        """ดึง session — ถ้า expired ให้ลบทิ้งและ return None"""
        session = self._sessions.get(user_id)
        if session is None:
            return None

        if session.is_expired(self._timeout):
            logger.debug(f"⏰ Session expired for user {user_id}")
            self.clear(user_id)
            return None

        return session

    def clear(self, user_id: int):
        """ลบ session + ลบไฟล์รูป temp"""
        session = self._sessions.pop(user_id, None)
        if session and session.image_path:
            try:
                if os.path.exists(session.image_path):
                    os.remove(session.image_path)
                    logger.debug(f"🗑️ Removed temp image: {session.image_path}")
            except Exception as e:
                logger.warning(f"Could not remove temp image: {e}")

    def cleanup_expired(self):
        """เคลียร์ session ที่หมดอายุทั้งหมด (เรียกเป็นระยะ)"""
        expired_users = [
            uid for uid, s in self._sessions.items()
            if s.is_expired(self._timeout)
        ]
        for uid in expired_users:
            self.clear(uid)

        if expired_users:
            logger.info(f"🧹 Cleaned up {len(expired_users)} expired sessions")


# Singleton
_session_manager: Optional[SessionManager] = None


def get_session_manager() -> SessionManager:
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager
