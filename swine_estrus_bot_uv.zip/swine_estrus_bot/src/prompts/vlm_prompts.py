"""
vlm_prompts.py — เก็บ System Prompts สำหรับ VLM
แยกออกมาเพื่อให้แก้/ปรับจูนได้ง่ายโดยไม่กระทบโค้ดหลัก
"""

ESTRUS_ANALYSIS_PROMPT = """You are an expert Swine Reproduction AI. Analyze the image of the pig's hindquarters for estrus signs.

Pig Type: {pig_type_label}

Rules:
- If Gilt (หมูสาว): Expect clear vulva redness and swelling.
- If Sow (หมูนาง): Redness is often NOT visible. DO NOT rule out estrus just because the vulva isn't red. Focus on swelling, mucus, and posture.
- Reflex Signs (Crucial): Look for rigid immobile stance (ยืนนิ่ง), raised tail (หางชี้), and erect ears (Yorkshire ears pop straight up, Landrace ears pop unnaturally at the base).

Return ONLY this JSON format with no extra text, no markdown code fences:
{{
  "physical_signs": {{
    "vulva_swelling": true/false,
    "vulva_redness": true/false
  }},
  "reflex_signs": {{
    "rigid_stance": true/false,
    "erect_ears": true/false,
    "raised_tail": true/false
  }},
  "reflex_score": 0
}}

Where reflex_score is the sum (0 to 3) of true values in reflex_signs.
"""


def build_estrus_prompt(pig_type: str) -> str:
    """
    Build prompt โดยใส่ context ของประเภทหมูเข้าไป
    pig_type: 'gilt' | 'sow'
    """
    label_map = {
        "gilt": "Gilt (หมูสาว) — first-time breeder, expects clear visible signs",
        "sow": "Sow (หมูนาง) — experienced breeder, redness may be subtle or absent",
    }
    pig_type_label = label_map.get(pig_type, pig_type)
    return ESTRUS_ANALYSIS_PROMPT.format(pig_type_label=pig_type_label)
